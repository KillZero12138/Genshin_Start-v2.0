import cv2
import threading
from playsound import playsound
import top
import time
def video():

    cap = cv2.VideoCapture("Start.mp4")
    fps = cap.get(cv2.CAP_PROP_FPS)
    while (True):

        ret, frame = cap.read()

        cv2.namedWindow("video", cv2.WINDOW_NORMAL)
        cv2.setWindowProperty("video", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        cv2.imshow("video", frame)
        top.run()
        if cv2.waitKey(int(1000 / fps)) & 0xFF == ord('q'):
            break

    cap.release()

    cv2.destroyAllWindows()

def music():
    playsound("Start.mp3")

def run():
    vd = threading.Thread(target=video)
    mc = threading.Thread(target=music)
    vd.start()
    mc.start()
